#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Run Flask app with public tunnel via pyngrok"""

import sys
import os
from pathlib import Path

# Add app to path
sys.path.insert(0, str(Path(__file__).parent))

from app.app import create_app
from pyngrok import ngrok
import time

# Create Flask app
app = create_app()

if __name__ == "__main__":
    try:
        # Create a tunnel to the development server
        print("\n" + "="*60)
        print("[*] Starting Flask app with public tunnel...")
        print("="*60)
        
        # Start ngrok tunnel
        public_url = ngrok.connect(5000, "http")
        print(f"\n[+] Public URL: {public_url}")
        print(f"[+] Local URL:  http://localhost:5000")
        print("\n" + "="*60)
        print("[+] Your app is live on the internet!")
        print("="*60 + "\n")
        
        # Run the Flask app
        app.run(debug=False, host="127.0.0.1", port=5000)
        
    except KeyboardInterrupt:
        print("\n\n[!] Shutting down...")
        ngrok.kill()
    except Exception as e:
        print(f"\n[-] Error: {e}")
        ngrok.kill()
