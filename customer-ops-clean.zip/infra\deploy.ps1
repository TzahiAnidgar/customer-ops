param(
    [Parameter(Mandatory = $true)][string]$TenantId,
    [Parameter(Mandatory = $true)][string]$SubscriptionId,
    [Parameter(Mandatory = $true)][string]$ResourceGroupName,
    [Parameter(Mandatory = $true)][string]$Location,
    [Parameter(Mandatory = $true)][string]$AppName,
    [Parameter(Mandatory = $true)][string]$StorageName
)

$ErrorActionPreference = "Stop"

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$packagePath = Join-Path $repoRoot "publish.zip"
$stagingRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("customer-ops-package-" + [Guid]::NewGuid().ToString("N"))
$startupCommandPath = Join-Path $repoRoot "startup.txt"
$startupCommand = (Get-Content $startupCommandPath -Raw).Trim()
$templateFile = Join-Path $PSScriptRoot "main.bicep"

function Copy-DeployFile {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination
    )

    $destinationDir = Split-Path -Parent $Destination
    if (-not (Test-Path $destinationDir)) {
        New-Item -ItemType Directory -Force -Path $destinationDir | Out-Null
    }

    Copy-Item -Path $Source -Destination $Destination -Force
}

function Copy-DeployFolderContents {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination
    )

    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    Copy-Item -Path (Join-Path $Source "*") -Destination $Destination -Recurse -Force
}

az account show --only-show-errors 1>$null 2>$null
if ($LASTEXITCODE -ne 0) {
    az login --tenant $TenantId | Out-Null
}
az account set --subscription $SubscriptionId

az group create `
    --name $ResourceGroupName `
    --location $Location | Out-Null

az deployment group create `
    --resource-group $ResourceGroupName `
    --template-file $templateFile `
    --parameters appName=$AppName storageName=$StorageName location=$Location startupCommand="$startupCommand"

$connectionString = az storage account show-connection-string `
    --resource-group $ResourceGroupName `
    --name $StorageName `
    --query connectionString `
    --output tsv

if (Test-Path $packagePath) {
    Remove-Item $packagePath -Force
}

if (Test-Path $stagingRoot) {
    Remove-Item $stagingRoot -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $stagingRoot | Out-Null
Copy-DeployFile -Source (Join-Path $repoRoot "app\app.py") -Destination (Join-Path $stagingRoot "app.py")
Copy-DeployFolderContents -Source (Join-Path $repoRoot "app\templates") -Destination (Join-Path $stagingRoot "templates")
Copy-DeployFolderContents -Source (Join-Path $repoRoot "app\static") -Destination (Join-Path $stagingRoot "static")
Copy-DeployFile -Source (Join-Path $repoRoot "requirements.txt") -Destination (Join-Path $stagingRoot "requirements.txt")
Copy-DeployFile -Source (Join-Path $repoRoot "startup.txt") -Destination (Join-Path $stagingRoot "startup.txt")
Copy-DeployFile -Source (Join-Path $repoRoot "startup.sh") -Destination (Join-Path $stagingRoot "startup.sh")
Copy-DeployFile -Source (Join-Path $repoRoot "wsgi.py") -Destination (Join-Path $stagingRoot "wsgi.py")
if (Test-Path (Join-Path $repoRoot "seed-data")) {
    Copy-DeployFolderContents -Source (Join-Path $repoRoot "seed-data") -Destination (Join-Path $stagingRoot "seed-data")
}

$pythonExe = $null
foreach ($candidate in @("python", "py")) {
    $commandInfo = Get-Command $candidate -ErrorAction SilentlyContinue
    if ($null -ne $commandInfo) {
        $pythonExe = $commandInfo.Path
        if (-not $pythonExe) {
            $pythonExe = $commandInfo.Source
        }
        break
    }
}

if (-not $pythonExe) {
    throw "Python executable not found. Install Python 3 before running the deployment."
}

$env:STAGING_ROOT = $stagingRoot
@'
import base64
import json
import os
import pathlib

root = pathlib.Path(os.environ["STAGING_ROOT"])
templates_dir = root / "templates"
template_names = ["base.html", "index.html", "customer_details.html"]
templates = {}
for template_name in template_names:
    template_path = templates_dir / template_name
    if template_path.exists():
        templates[template_name] = template_path.read_text(encoding="utf-8")

static_assets = {}
static_dir = root / "static"
if static_dir.exists():
    for static_file in static_dir.iterdir():
        if static_file.is_file():
            if static_file.suffix.lower() in [".css", ".js"]:
                static_assets[static_file.name] = static_file.read_text(encoding="utf-8")
            else:
                static_assets[static_file.name] = base64.b64encode(static_file.read_bytes()).decode("ascii")

seed_db_path = root / "seed-data" / "customer_ops.db"
seed_db_b64 = ""
if seed_db_path.exists():
    seed_db_b64 = base64.b64encode(seed_db_path.read_bytes()).decode("ascii")

runtime_assets = [
    "# Generated by deploy.ps1",
    "TEMPLATES = " + json.dumps(templates, ensure_ascii=False, indent=2),
    "STATIC_ASSETS = " + json.dumps(static_assets, ensure_ascii=False, indent=2),
    "SEED_DB_B64 = " + json.dumps(seed_db_b64),
    "",
]
(root / "runtime_assets.py").write_text("\n".join(runtime_assets), encoding="utf-8")
'@ | & $pythonExe -

$sitePackagesPath = Join-Path $stagingRoot ".python_packages\lib\site-packages"
New-Item -ItemType Directory -Force -Path $sitePackagesPath | Out-Null
& $pythonExe -m pip install --disable-pip-version-check --no-cache-dir --target $sitePackagesPath -r (Join-Path $repoRoot "requirements.txt")

$pyCachePaths = Get-ChildItem -Path $stagingRoot -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue
foreach ($cachePath in $pyCachePaths) {
    Remove-Item $cachePath.FullName -Recurse -Force
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($stagingRoot, $packagePath)

az webapp config appsettings set `
    --resource-group $ResourceGroupName `
    --name "$AppName-web" `
    --settings WEBSITE_RUN_FROM_PACKAGE=1 SCM_DO_BUILD_DURING_DEPLOYMENT=0 AZURE_STORAGE_CONNECTION_STRING="$connectionString" AZURE_BLOB_CONTAINER="customer-documents" CUSTOMER_OPS_SEED_DIR="/home/site/wwwroot/seed-data" | Out-Null

az webapp deployment source config-zip `
    --resource-group $ResourceGroupName `
    --name "$AppName-web" `
    --src $packagePath | Out-Null

Write-Host "Deployment completed with run-from-package zip."

if (Test-Path $stagingRoot) {
    Remove-Item $stagingRoot -Recurse -Force
}
