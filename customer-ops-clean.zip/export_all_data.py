#!/usr/bin/env python3
"""
Data Export & Backup Script
============================
Exports all data from customer_ops.db to JSON for archival and migration

Usage:
    python export_all_data.py --db customer_ops.db --output backup.json
    
    Or directly from Azure:
    - Download database from App Service (via portal or azure-cli)
    - Run this script
"""

import sqlite3
import json
import sys
from datetime import datetime
from pathlib import Path

def export_database(db_path, output_path=None):
    """Export entire database to JSON"""
    
    if output_path is None:
        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        output_path = f'customer_ops_backup_{timestamp}.json'
    
    print(f"📖 Opening database: {db_path}")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    backup = {
        'exported_at': datetime.now().isoformat(),
        'database_file': str(db_path),
        'tables': {}
    }
    
    # Get all table names
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row[0] for row in cursor.fetchall()]
    
    print(f"\n📋 Found {len(tables)} tables")
    
    for table_name in tables:
        print(f"\n  Exporting table: {table_name}")
        cursor.execute(f"SELECT * FROM {table_name}")
        
        columns = [description[0] for description in cursor.description]
        rows = cursor.fetchall()
        
        table_data = {
            'columns': columns,
            'row_count': len(rows),
            'rows': [dict(row) for row in rows]
        }
        
        backup['tables'][table_name] = table_data
        print(f"    ✓ {len(rows)} rows exported")
    
    # Write JSON backup
    print(f"\n💾 Writing backup to: {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(backup, f, indent=2, default=str)
    
    conn.close()
    
    file_size = Path(output_path).stat().st_size
    print(f"✅ Backup complete! ({file_size:,} bytes)")
    print(f"\n📊 Summary:")
    
    total_rows = sum(table['row_count'] for table in backup['tables'].values())
    print(f"   Total rows: {total_rows}")
    print(f"   Total tables: {len(backup['tables'])}")
    print(f"   Backup location: {output_path}")
    
    return output_path

def restore_from_json(json_path, db_path='customer_ops_restored.db'):
    """Restore database from JSON backup"""
    
    print(f"📖 Reading backup: {json_path}")
    with open(json_path, 'r', encoding='utf-8') as f:
        backup = json.load(f)
    
    print(f"⚙️  Creating new database: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    for table_name, table_data in backup['tables'].items():
        columns = table_data['columns']
        rows = table_data['rows']
        
        print(f"\n  Restoring table: {table_name}")
        print(f"    Columns: {', '.join(columns)}")
        
        # Create table
        placeholders = ', '.join(['?' for _ in columns])
        insert_sql = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({placeholders})"
        
        # Insert rows
        for row in rows:
            values = [row.get(col) for col in columns]
            cursor.execute(insert_sql, values)
        
        print(f"    ✓ {len(rows)} rows restored")
        conn.commit()
    
    conn.close()
    print(f"\n✅ Database restore complete!")
    print(f"   Location: {db_path}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage:")
        print("  export: python export_all_data.py export <db_path> [output.json]")
        print("  restore: python export_all_data.py restore <json_path> [output.db]")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'export' and len(sys.argv) >= 3:
        db_path = sys.argv[2]
        output_path = sys.argv[3] if len(sys.argv) > 3 else None
        export_database(db_path, output_path)
    
    elif command == 'restore' and len(sys.argv) >= 3:
        json_path = sys.argv[2]
        db_path = sys.argv[3] if len(sys.argv) > 3 else 'customer_ops_restored.db'
        restore_from_json(json_path, db_path)
    
    else:
        print("Invalid command or arguments")
        sys.exit(1)
