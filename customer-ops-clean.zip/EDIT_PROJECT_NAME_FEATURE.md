# ✨ Edit Project Name Feature

## Overview
Added capability to rename projects **after creation** without losing any associated data (sub-projects, tasks, documents, time windows).

## Implementation Details

### Backend Routes

#### 1. Edit Main Project Name
```
POST /customers/<customer_id>/name
```
**Parameters:**
- `name` (string, max 255 chars) - New project name
- `status_filter` (optional) - Maintain filter state
- `workspace` (optional) - Maintain workspace context

**Validation:**
- Validates project exists
- Checks name is not empty
- Limits to 255 characters
- Returns success/error flash message

**Database Impact:**
- Updates `customers.name` only
- No cascading deletes or changes
- All sub-projects and tasks remain intact

#### 2. Edit Sub-Project Name
```
POST /projects/<project_id>/name
```
**Parameters:**
- `name` (string, max 255 chars) - New sub-project name

**Validation:**
- Validates sub-project exists
- Checks name is not empty
- Limits to 255 characters
- Returns success/error flash message
- Redirects back to customer details

**Database Impact:**
- Updates `projects.name` only
- No cascading deletes or changes
- All tasks and time windows remain intact

### Frontend Changes

#### index.html - Main Projects Table
Changed from:
```html
<span class="project-name">{{ c["name"] }}</span>
```

To:
```html
<form method="post" action="{{ url_for('update_customer_name', customer_id=c['id']) }}" class="inline-edit-form project-name-form">
    <input type="hidden" name="status_filter" value="{{ selected_project_status_filter }}">
    <input type="hidden" name="workspace" value="{{ workspace }}">
    <input type="text" name="name" value="{{ c['name'] }}" class="project-name-input" required>
    <button type="submit" class="secondary tiny-edit">✓</button>
</form>
```

#### customer_details.html - Sub-Projects
Changed from:
```html
<h4>{{ project["name"] }} ({{ project["status"] }})</h4>
```

To:
```html
<div class="project-header">
    <form method="post" action="{{ url_for('update_project_name', project_id=project['id']) }}" class="inline-edit-form project-edit-form">
        <input type="text" name="name" value="{{ project['name'] }}" class="project-title-input" required>
        <span class="project-status-inline">({{ project["status"] }})</span>
        <button type="submit" class="secondary tiny-edit" title="Save name">✓</button>
    </form>
</div>
```

### Styling (base.html)
Added CSS for inline edit forms:
```css
.inline-edit-form { display: inline-flex; align-items: center; gap: 0.4rem; }
.project-name-input, .project-title-input { 
    padding: 0.3rem 0.5rem; 
    border: 1px solid #ddd; 
    border-radius: 4px; 
}
.project-name-input:focus, .project-title-input:focus {
    outline: none;
    border-color: #1f57d6;
    box-shadow: 0 0 0 2px rgba(31, 87, 214, 0.1);
}
.tiny-edit { padding: 0.2rem 0.4rem; font-size: 0.75rem; }
```

## User Experience

### Main Project (in Tracker table)
1. User sees project name in input field
2. Clicks and edits name
3. Presses Enter or clicks ✓ button
4. Form submits, page reloads with success message
5. Filter and workspace selection preserved

### Sub-Project (in Details page)
1. User opens project details
2. Sees sub-project name in editable input
3. Edits name and clicks ✓ button
4. Form submits, page reloads with success message
5. Redirects back to same customer details page

## Data Safety

✅ **No data loss** - Only `name` field is updated
✅ **Referential integrity** - No cascading changes
✅ **Status preserved** - Project status remains unchanged
✅ **Related data intact** - All tasks, documents, time windows preserved
✅ **Audit trail** - Flash messages confirm changes

## Test Cases

1. ✓ Main project name edit (valid name)
2. ✓ Main project name edit (empty name - validation fails)
3. ✓ Main project name edit (very long name - validation fails)
4. ✓ Main project name edit (preserves filters/workspace)
5. ✓ Sub-project name edit (valid name)
6. ✓ Sub-project name edit (empty name - validation fails)
7. ✓ Sub-project name edit (very long name - validation fails)
8. ✓ Sub-project name edit (redirects to customer details)
9. ✓ Tasks remain linked after project rename
10. ✓ Documents remain linked after project rename

## Deployment

This feature is included in the current backup and will be deployed with the next app redeploy.

To deploy now:
```powershell
.\infra\deploy.ps1 -AppName "zivcxportal2026d" `
    -ResourceGroupName "Ziv-Cx-Portal-D" `
    -Location "westeurope" `
    -StorageName "zivcxstoraged" `
    -SubscriptionId "c60d27e5-5dc2-421d-a7d3-16f479b42b59" `
    -TenantId "<your-tenant-id>"
```

## File Changes Summary

| File | Type | Lines Added | Change |
|------|------|-------------|--------|
| app.py | Backend | 62 | 2 new route handlers |
| index.html | Frontend | 8 | Replace span with form |
| customer_details.html | Frontend | 11 | Replace h4 with form |
| base.html | Styling | 38 | New CSS classes |

## Rollback

If issues occur, revert these commits or redeploy from previous backup.

No database migration required - this is a pure code change.
